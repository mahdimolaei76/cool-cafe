# COOL Café Backend API

A production-ready Go backend for the COOL Café management system.

## Tech Stack

- **Go 1.21+**
- **PostgreSQL 15+**
- **Chi Router** - Lightweight HTTP router
- **sqlx** - SQL extensions for Go
- **JWT** - Authentication
- **Viper** - Configuration management

## Project Structure

```
backend/
├── cmd/
│   └── api/
│       └── main.go           # Application entry point
├── internal/
│   ├── config/
│   │   └── config.go         # Configuration management
│   ├── domain/
│   │   ├── category.go       # Category entity
│   │   ├── menu_item.go      # MenuItem entity
│   │   ├── order.go          # Order entity
│   │   └── user.go           # User entity
│   ├── repository/
│   │   ├── category_repo.go
│   │   ├── menu_item_repo.go
│   │   ├── order_repo.go
│   │   └── user_repo.go
│   ├── service/
│   │   ├── auth_service.go
│   │   ├── category_service.go
│   │   ├── menu_item_service.go
│   │   └── order_service.go
│   ├── handler/
│   │   ├── auth_handler.go
│   │   ├── category_handler.go
│   │   ├── menu_item_handler.go
│   │   ├── order_handler.go
│   │   └── upload_handler.go
│   ├── middleware/
│   │   ├── auth.go
│   │   ├── cors.go
│   │   └── logging.go
│   └── dto/
│       ├── request.go
│       └── response.go
├── migrations/
│   ├── 001_create_users.sql
│   ├── 002_create_categories.sql
│   ├── 003_create_menu_items.sql
│   └── 004_create_orders.sql
├── uploads/                   # Uploaded images
├── .env.example
├── go.mod
└── go.sum
```

## Getting Started

### Prerequisites

- Go 1.21+
- PostgreSQL 15+

### Installation

1. Clone the repository
2. Copy `.env.example` to `.env` and configure
3. Create PostgreSQL database
4. Run migrations
5. Start the server

```bash
cd backend
cp .env.example .env
# Edit .env with your database credentials

# Run migrations
psql -U postgres -d coolcafe -f migrations/001_create_users.sql
psql -U postgres -d coolcafe -f migrations/002_create_categories.sql
psql -U postgres -d coolcafe -f migrations/003_create_menu_items.sql
psql -U postgres -d coolcafe -f migrations/004_create_orders.sql

# Start server
go run cmd/api/main.go
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Get current user

### Categories
- `GET /api/categories` - List all categories
- `GET /api/categories/:id` - Get category
- `POST /api/categories` - Create category (admin)
- `PUT /api/categories/:id` - Update category (admin)
- `DELETE /api/categories/:id` - Delete category (admin)

### Menu Items
- `GET /api/menu` - List all menu items (public)
- `GET /api/menu/:id` - Get menu item
- `POST /api/menu` - Create menu item (admin)
- `PUT /api/menu/:id` - Update menu item (admin)
- `DELETE /api/menu/:id` - Delete menu item (admin)

### Orders
- `GET /api/orders` - List orders (admin)
- `GET /api/orders/:id` - Get order
- `POST /api/orders` - Create order (public)
- `PATCH /api/orders/:id/status` - Update order status (admin)

### Upload
- `POST /api/upload` - Upload image (admin)

## Environment Variables

```env
# Server
PORT=8080
ENV=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=your_password
DB_NAME=coolcafe

# JWT
JWT_SECRET=your_secret_key
JWT_EXPIRY=24h

# Upload
UPLOAD_DIR=./uploads
MAX_UPLOAD_SIZE=5242880
```

## License

MIT License
