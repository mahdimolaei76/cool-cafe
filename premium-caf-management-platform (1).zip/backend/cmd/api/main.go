package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"
	"github.com/jmoiron/sqlx"
	"github.com/joho/godotenv"
	_ "github.com/lib/pq"

	"github.com/coolcafe/backend/internal/handler"
	appMiddleware "github.com/coolcafe/backend/internal/middleware"
	"github.com/coolcafe/backend/internal/repository"
	"github.com/coolcafe/backend/internal/service"
)

func main() {
	// Load environment variables
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using environment variables")
	}

	// Database connection
	db, err := connectDB()
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer db.Close()

	// Initialize repositories
	userRepo := repository.NewUserRepository(db)
	categoryRepo := repository.NewCategoryRepository(db)
	menuItemRepo := repository.NewMenuItemRepository(db)
	orderRepo := repository.NewOrderRepository(db)

	// Initialize services
	jwtSecret := getEnv("JWT_SECRET", "default-secret-key")
	authService := service.NewAuthService(userRepo, jwtSecret)
	categoryService := service.NewCategoryService(categoryRepo)
	menuItemService := service.NewMenuItemService(menuItemRepo)
	orderService := service.NewOrderService(orderRepo)

	// Initialize handlers
	authHandler := handler.NewAuthHandler(authService)
	categoryHandler := handler.NewCategoryHandler(categoryService)
	menuItemHandler := handler.NewMenuItemHandler(menuItemService)
	orderHandler := handler.NewOrderHandler(orderService)
	uploadHandler := handler.NewUploadHandler(getEnv("UPLOAD_DIR", "./uploads"))

	// Auth middleware
	authMiddleware := appMiddleware.NewAuthMiddleware(jwtSecret)

	// Create router
	r := chi.NewRouter()

	// Global middleware
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)
	r.Use(middleware.Timeout(60 * time.Second))
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{"*"},
		AllowedMethods:   []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// API routes
	r.Route("/api", func(r chi.Router) {
		// Public routes
		r.Post("/auth/login", authHandler.Login)
		r.Get("/categories", categoryHandler.List)
		r.Get("/menu", menuItemHandler.List)
		r.Get("/menu/{id}", menuItemHandler.Get)
		r.Post("/orders", orderHandler.Create) // Public order creation

		// Protected routes
		r.Group(func(r chi.Router) {
			r.Use(authMiddleware.Authenticate)

			// Auth
			r.Get("/auth/me", authHandler.Me)
			r.Post("/auth/logout", authHandler.Logout)

			// Categories (admin only)
			r.Post("/categories", categoryHandler.Create)
			r.Put("/categories/{id}", categoryHandler.Update)
			r.Delete("/categories/{id}", categoryHandler.Delete)

			// Menu Items (admin only)
			r.Post("/menu", menuItemHandler.Create)
			r.Put("/menu/{id}", menuItemHandler.Update)
			r.Delete("/menu/{id}", menuItemHandler.Delete)

			// Orders (admin/cashier)
			r.Get("/orders", orderHandler.List)
			r.Get("/orders/{id}", orderHandler.Get)
			r.Patch("/orders/{id}/status", orderHandler.UpdateStatus)

			// Upload
			r.Post("/upload", uploadHandler.Upload)
		})
	})

	// Serve static files (uploads)
	r.Handle("/uploads/*", http.StripPrefix("/uploads/", http.FileServer(http.Dir(getEnv("UPLOAD_DIR", "./uploads")))))

	// Health check
	r.Get("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("OK"))
	})

	// Start server
	port := getEnv("PORT", "8080")
	log.Printf("🚀 Server starting on port %s", port)
	log.Fatal(http.ListenAndServe(":"+port, r))
}

func connectDB() (*sqlx.DB, error) {
	dsn := fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		getEnv("DB_HOST", "localhost"),
		getEnv("DB_PORT", "5432"),
		getEnv("DB_USER", "postgres"),
		getEnv("DB_PASSWORD", ""),
		getEnv("DB_NAME", "coolcafe"),
		getEnv("DB_SSLMODE", "disable"),
	)

	db, err := sqlx.Connect("postgres", dsn)
	if err != nil {
		return nil, err
	}

	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)
	db.SetConnMaxLifetime(5 * time.Minute)

	return db, nil
}

func getEnv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
