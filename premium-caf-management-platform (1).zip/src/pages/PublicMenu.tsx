import { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ShoppingBag, Menu, X } from 'lucide-react';
import { cn } from '@/utils/cn';
import { useAppStore, useCartStore, formatPrice } from '@/store';
import MenuHero from '@/components/menu/MenuHero';
import MenuItemCard from '@/components/menu/MenuItemCard';
import CartSheet from '@/components/menu/CartSheet';
import MenuSidebar from '@/components/menu/MenuSidebar';

export default function PublicMenu() {
  const { menuItems, categories } = useAppStore();
  const cartItemCount = useCartStore(s => s.getItemCount());
  const cartTotal = useCartStore(s => s.getTotal());
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cartOpen, setCartOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const catScrollRef = useRef<HTMLDivElement>(null);

  const activeCategories = categories.filter(c => c.isActive).sort((a, b) => a.order - b.order);

  const filteredItems = useMemo(() => {
    let items = menuItems;
    if (selectedCategory !== 'all') {
      items = items.filter(i => i.categoryId === selectedCategory);
    }
    if (search) {
      const q = search.toLowerCase();
      items = items.filter(i => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q));
    }
    return items;
  }, [menuItems, selectedCategory, search]);

  const featuredItems = useMemo(() => menuItems.filter(i => i.isFeatured && i.isAvailable), [menuItems]);

  useEffect(() => {
    if (catScrollRef.current) {
      const activeEl = catScrollRef.current.querySelector('[data-active="true"]');
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [selectedCategory]);

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-950">
      <MenuHero />

      {/* Sticky Nav */}
      <div className="sticky top-0 z-30 bg-white/95 dark:bg-surface-900/95 backdrop-blur-xl border-b border-surface-200/60 dark:border-surface-800">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center gap-2 py-3 h-14">
            {/* Menu */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2.5 rounded-xl bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-surface-400 hover:bg-surface-200 dark:hover:bg-surface-700 transition-colors flex-shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Category pills */}
            <div ref={catScrollRef} className="flex-1 overflow-x-auto flex items-center gap-2 no-scrollbar">
              <button
                data-active={selectedCategory === 'all'}
                onClick={() => setSelectedCategory('all')}
                className={cn(
                  'flex-shrink-0 px-4 py-2 rounded-full text-sm font-bold transition-all duration-200 whitespace-nowrap',
                  selectedCategory === 'all'
                    ? 'bg-brand-600 text-white shadow-md shadow-brand-500/25'
                    : 'bg-surface-100 text-surface-600 hover:bg-surface-200 dark:bg-surface-800 dark:text-surface-400 dark:hover:bg-surface-700'
                )}
              >
                همه
              </button>
              {activeCategories.map(cat => (
                <button
                  key={cat.id}
                  data-active={selectedCategory === cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    'flex-shrink-0 px-4 py-2 rounded-full text-sm font-bold transition-all duration-200 whitespace-nowrap',
                    selectedCategory === cat.id
                      ? 'bg-brand-600 text-white shadow-md shadow-brand-500/25'
                      : 'bg-surface-100 text-surface-600 hover:bg-surface-200 dark:bg-surface-800 dark:text-surface-400 dark:hover:bg-surface-700'
                  )}
                >
                  <span className="ml-1">{cat.icon}</span>
                  {cat.name}
                </button>
              ))}
            </div>

            {/* Search */}
            <button
              onClick={() => setShowSearch(!showSearch)}
              className="p-2.5 rounded-xl bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-surface-400 hover:bg-surface-200 dark:hover:bg-surface-700 transition-colors flex-shrink-0"
            >
              {showSearch ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
            </button>
          </div>

          {/* Search bar - expandable */}
          <AnimatePresence>
            {showSearch && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="overflow-hidden"
              >
                <div className="pb-3">
                  <div className="relative">
                    <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-surface-400" />
                    <input
                      type="text"
                      placeholder="چی میخوای سفارش بدی؟"
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      autoFocus
                      className="w-full pr-12 pl-4 py-3 rounded-2xl bg-surface-100 dark:bg-surface-800 text-base text-surface-900 dark:text-surface-100 placeholder:text-surface-400 focus:outline-none focus:ring-2 focus:ring-brand-500/30 font-medium"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-4 pb-36">
        {/* Featured Section */}
        {selectedCategory === 'all' && !search && featuredItems.length > 0 && (
          <section className="mt-8">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-brand-100 dark:bg-brand-900/30 rounded-xl flex items-center justify-center">
                <span className="text-xl">⭐</span>
              </div>
              <div>
                <h2 className="text-xl font-black text-surface-900 dark:text-surface-100">پیشنهاد ویژه</h2>
                <p className="text-xs text-surface-400 mt-0.5">منتخب سرآشپز</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {featuredItems.slice(0, 6).map((item, i) => (
                <MenuItemCard key={item.id} item={item} index={i} />
              ))}
            </div>
          </section>
        )}

        {/* Menu Grid by Category */}
        {selectedCategory === 'all' && !search ? (
          activeCategories.map(cat => {
            const catItems = menuItems.filter(i => i.categoryId === cat.id);
            if (catItems.length === 0) return null;
            return (
              <section key={cat.id} className="mt-12">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 bg-surface-100 dark:bg-surface-800 rounded-xl flex items-center justify-center">
                    <span className="text-xl">{cat.icon}</span>
                  </div>
                  <div>
                    <h2 className="text-xl font-black text-surface-900 dark:text-surface-100">{cat.name}</h2>
                    <p className="text-xs text-surface-400 mt-0.5">{catItems.length} محصول</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {catItems.map((item, i) => (
                    <MenuItemCard key={item.id} item={item} index={i} />
                  ))}
                </div>
              </section>
            );
          })
        ) : (
          <section className="mt-8">
            {filteredItems.length > 0 ? (
              <>
                <p className="text-sm text-surface-500 dark:text-surface-400 mb-4 font-medium">
                  {filteredItems.length} محصول
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {filteredItems.map((item, i) => (
                    <MenuItemCard key={item.id} item={item} index={i} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-24">
                <div className="w-20 h-20 bg-surface-100 dark:bg-surface-800 rounded-3xl mx-auto mb-4 flex items-center justify-center">
                  <Search className="w-9 h-9 text-surface-300 dark:text-surface-600" />
                </div>
                <p className="text-surface-500 dark:text-surface-400 font-bold text-lg">موردی یافت نشد</p>
                <p className="text-surface-400 dark:text-surface-500 text-sm mt-1">عبارت دیگری جستجو کنید</p>
              </div>
            )}
          </section>
        )}
      </div>

      {/* Floating Cart Button */}
      <AnimatePresence>
        {cartItemCount > 0 && (
          <motion.div
            initial={{ y: 120, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 120, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-40 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]"
          >
            <div className="max-w-md mx-auto">
              <button
                onClick={() => setCartOpen(true)}
                className="w-full flex items-center justify-between px-6 py-4 bg-brand-600 text-white rounded-2xl shadow-2xl shadow-brand-600/40 hover:bg-brand-700 transition-colors active:scale-[0.98]"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <ShoppingBag className="w-6 h-6" />
                    <span className="absolute -top-2 -right-2 w-5 h-5 bg-white text-brand-700 text-[11px] font-black rounded-full flex items-center justify-center shadow">
                      {cartItemCount}
                    </span>
                  </div>
                  <span className="font-bold">مشاهده سبد خرید</span>
                </div>
                <span className="font-black text-lg">{formatPrice(cartTotal)}</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <CartSheet open={cartOpen} onClose={() => setCartOpen(false)} />
      <MenuSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
    </div>
  );
}
