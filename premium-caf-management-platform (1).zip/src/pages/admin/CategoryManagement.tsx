import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit2, Trash2, GripVertical } from 'lucide-react';
import { useAppStore } from '@/store';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import type { Category } from '@/types';

export default function CategoryManagement() {
  const { categories, menuItems, addCategory, updateCategory, deleteCategory } = useAppStore();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', slug: '', icon: '☕', order: 0, isActive: true });

  const sorted = [...categories].sort((a, b) => a.order - b.order);

  const openCreate = () => {
    setEditingCat(null);
    setForm({ name: '', slug: '', icon: '☕', order: categories.length + 1, isActive: true });
    setModalOpen(true);
  };

  const openEdit = (cat: Category) => {
    setEditingCat(cat);
    setForm({ name: cat.name, slug: cat.slug, icon: cat.icon, order: cat.order, isActive: cat.isActive });
    setModalOpen(true);
  };

  const handleSave = () => {
    const slug = form.name.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '-').replace(/(^-|-$)/g, '');
    if (editingCat) {
      updateCategory(editingCat.id, { ...form, slug });
    } else {
      addCategory({ ...form, slug });
    }
    setModalOpen(false);
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteCategory(deleteId);
      setDeleteId(null);
    }
  };

  const emojiOptions = ['☕', '🧊', '🍵', '🎂', '🍰', '🥐', '🍳', '🥪', '🥤', '🍕', '🥗', '🍩', '🧁', '🥞', '🍔'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 dark:text-surface-100">دسته‌بندی‌ها</h1>
          <p className="text-sm text-surface-500 dark:text-surface-400 mt-1">{categories.length} دسته‌بندی</p>
        </div>
        <Button onClick={openCreate} icon={<Plus className="w-4 h-4" />}>افزودن دسته‌بندی</Button>
      </div>

      <Card>
        <div className="space-y-2">
          <AnimatePresence>
            {sorted.map(cat => {
              const itemCount = menuItems.filter(m => m.categoryId === cat.id).length;
              return (
                <motion.div
                  key={cat.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: 50 }}
                  className="flex items-center gap-4 p-4 rounded-xl bg-surface-50 dark:bg-surface-800/50 hover:bg-surface-100 dark:hover:bg-surface-800 transition-colors group"
                >
                  <GripVertical className="w-4 h-4 text-surface-300 dark:text-surface-600 flex-shrink-0 cursor-grab" />
                  <span className="text-2xl flex-shrink-0">{cat.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium text-surface-900 dark:text-surface-100">{cat.name}</h3>
                      <Badge variant={cat.isActive ? 'success' : 'default'} dot>{cat.isActive ? 'فعال' : 'غیرفعال'}</Badge>
                    </div>
                    <p className="text-xs text-surface-400 mt-0.5">{itemCount} آیتم · ترتیب: {cat.order}</p>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => openEdit(cat)} className="p-2 rounded-lg text-surface-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => setDeleteId(cat.id)} className="p-2 rounded-lg text-surface-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingCat ? 'ویرایش دسته‌بندی' : 'افزودن دسته‌بندی'}>
        <div className="p-6 space-y-4">
          <Input label="نام" placeholder="نام دسته‌بندی" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
          <div>
            <label className="block text-sm font-medium text-surface-700 dark:text-surface-300 mb-1.5">آیکون</label>
            <div className="flex flex-wrap gap-2">
              {emojiOptions.map(emoji => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setForm(p => ({ ...p, icon: emoji }))}
                  className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all ${form.icon === emoji ? 'bg-brand-100 ring-2 ring-brand-500 dark:bg-brand-900/30' : 'bg-surface-100 dark:bg-surface-800 hover:bg-surface-200 dark:hover:bg-surface-700'}`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          <Input label="ترتیب نمایش" type="number" value={String(form.order)} onChange={e => setForm(p => ({ ...p, order: parseInt(e.target.value) || 0 }))} />
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.isActive} onChange={e => setForm(p => ({ ...p, isActive: e.target.checked }))} className="w-4 h-4 rounded border-surface-300 text-brand-600 focus:ring-brand-500" />
            <span className="text-sm text-surface-700 dark:text-surface-300">فعال</span>
          </label>
          <div className="flex justify-end gap-3 pt-4 border-t border-surface-100 dark:border-surface-800">
            <Button variant="outline" onClick={() => setModalOpen(false)}>انصراف</Button>
            <Button onClick={handleSave} disabled={!form.name}>{editingCat ? 'ذخیره' : 'افزودن'}</Button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="حذف دسته‌بندی"
        message="تمام آیتم‌های این دسته‌بندی بدون دسته می‌شوند. ادامه می‌دهید؟"
        confirmText="حذف"
      />
    </div>
  );
}
