import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus, Trash2, Search, Check, ShoppingCart, User, CreditCard, Banknote, Smartphone, Receipt, Flame, Star, Zap, Coffee } from 'lucide-react';
import { useAppStore, formatPrice } from '@/store';
import { useAuthStore } from '@/store/authStore';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Modal from '@/components/ui/Modal';
import type { OrderType, PaymentMethod, MenuItem } from '@/types';

interface CartEntry {
  menuItem: MenuItem;
  quantity: number;
}

export default function NewOrder() {
  const { menuItems, categories, orders, addOrder } = useAppStore();
  const user = useAuthStore(s => s.user);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [success, setSuccess] = useState<string | null>(null);
  const [customerModal, setCustomerModal] = useState(false);
  const [form, setForm] = useState({
    firstName: '', lastName: '', phone: '', notes: '',
    discount: 0, orderType: 'in-person' as OrderType,
    paymentMethod: 'cash' as PaymentMethod,
  });

  const activeCategories = categories.filter(c => c.isActive).sort((a, b) => a.order - b.order);

  // محاسبه پرفروش‌ترین محصولات
  const topSellingItems = useMemo(() => {
    const salesCount: Record<string, number> = {};
    orders.forEach(order => {
      if (order.status !== 'cancelled') {
        order.items.forEach(item => {
          salesCount[item.menuItemId] = (salesCount[item.menuItemId] || 0) + item.quantity;
        });
      }
    });
    return Object.entries(salesCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([id]) => id);
  }, [orders]);

  

  const filteredItems = useMemo(() => {
    let items = menuItems.filter(m => m.isAvailable);
    if (selectedCategory !== 'all') {
      items = items.filter(i => i.categoryId === selectedCategory);
    }
    if (search) {
      const q = search.toLowerCase();
      items = items.filter(m => m.name.toLowerCase().includes(q));
    }
    return items;
  }, [menuItems, selectedCategory, search]);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.menuItem.id === item.id);
      if (existing) return prev.map(c => c.menuItem.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { menuItem: item, quantity: 1 }];
    });
  };

  const updateQty = (id: string, qty: number) => {
    if (qty <= 0) {
      setCart(prev => prev.filter(c => c.menuItem.id !== id));
    } else {
      setCart(prev => prev.map(c => c.menuItem.id === id ? { ...c, quantity: qty } : c));
    }
  };

  const subtotal = cart.reduce((s, c) => s + c.menuItem.price * c.quantity, 0);
  const total = Math.max(0, subtotal - form.discount);
  const itemCount = cart.reduce((s, c) => s + c.quantity, 0);

  const handleSubmit = () => {
    if (cart.length === 0) return;
    const order = addOrder({
      customerFirstName: form.firstName || 'مشتری',
      customerLastName: form.lastName || 'حضوری',
      customerPhone: form.phone,
      items: cart.map(c => ({
        id: crypto.randomUUID(),
        menuItemId: c.menuItem.id,
        menuItem: c.menuItem,
        name: c.menuItem.name,
        price: c.menuItem.price,
        quantity: c.quantity,
        subtotal: c.menuItem.price * c.quantity,
      })),
      subtotal,
      discount: form.discount,
      total,
      notes: form.notes,
      status: 'pending',
      orderType: form.orderType,
      paymentMethod: form.paymentMethod,
      cashier: user?.name || '',
    });
    setSuccess(order.orderNumber);
  };

  const resetOrder = () => {
    setCart([]);
    setForm({ firstName: '', lastName: '', phone: '', notes: '', discount: 0, orderType: 'in-person', paymentMethod: 'cash' });
    setSuccess(null);
  };

  // Success Screen
  if (success) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-md mx-auto"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: 'spring', stiffness: 200 }}
            className="w-28 h-28 mx-auto mb-8 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-[2rem] flex items-center justify-center shadow-2xl shadow-emerald-500/40"
          >
            <Check className="w-14 h-14 text-white" strokeWidth={3} />
          </motion.div>
          <h2 className="text-4xl font-black text-surface-900 dark:text-surface-100">سفارش ثبت شد!</h2>
          <div className="mt-8 p-8 bg-white dark:bg-surface-800 rounded-3xl shadow-xl border border-surface-100 dark:border-surface-700">
            <p className="text-sm text-surface-400 mb-2">شماره سفارش</p>
            <p className="text-5xl font-black text-brand-600 font-mono tracking-wider" dir="ltr">{success}</p>
          </div>
          <div className="mt-6 p-5 bg-brand-50 dark:bg-brand-900/20 rounded-2xl border-2 border-brand-200 dark:border-brand-800">
            <p className="text-xl font-bold text-brand-700 dark:text-brand-400">مبلغ قابل پرداخت: {formatPrice(total)}</p>
          </div>
          <div className="flex gap-4 mt-10">
            <Button variant="outline" className="flex-1 !py-4 !text-base !rounded-2xl" size="lg" onClick={() => window.print()}>
              <Receipt className="w-5 h-5 ml-2" />
              چاپ رسید
            </Button>
            <Button className="flex-1 !py-4 !text-base !rounded-2xl !bg-brand-600 hover:!bg-brand-700" size="lg" onClick={resetOrder}>
              <Plus className="w-5 h-5 ml-2" />
              سفارش جدید
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-100px)] flex gap-5">
      {/* Left Side - Menu Items */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Quick Tags */}
        <div className="mb-5 space-y-3">
          {/* پرفروش‌ها */}
          {topSellingItems.length > 0 && (
            <div className="bg-gradient-to-r from-brand-50 to-orange-50 dark:from-brand-900/20 dark:to-orange-900/20 rounded-2xl p-4 border border-brand-100 dark:border-brand-800">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
                  <Flame className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-brand-800 dark:text-brand-400">پرفروش‌ترین‌ها</span>
                <span className="text-xs text-brand-500 bg-brand-100 dark:bg-brand-900/50 px-2 py-0.5 rounded-full">کلیک سریع</span>
              </div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar">
                {topSellingItems.map(id => {
                  const item = menuItems.find(m => m.id === id);
                  if (!item) return null;
                  const inCart = cart.find(c => c.menuItem.id === item.id);
                  return (
                    <motion.button
                      key={id}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => addToCart(item)}
                      className={`flex-shrink-0 flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                        inCart 
                          ? 'bg-brand-600 text-white shadow-lg shadow-brand-500/30' 
                          : 'bg-white dark:bg-surface-800 border border-surface-200 dark:border-surface-700 hover:border-brand-400 hover:shadow-md'
                      }`}
                    >
                      <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="text-right">
                        <p className={`font-bold text-sm ${inCart ? 'text-white' : 'text-surface-900 dark:text-surface-100'}`}>{item.name}</p>
                        <p className={`text-xs ${inCart ? 'text-white/80' : 'text-brand-600'}`}>{formatPrice(item.price)}</p>
                      </div>
                      {inCart && (
                        <span className="w-6 h-6 bg-white text-brand-600 rounded-full flex items-center justify-center text-xs font-bold">
                          {inCart.quantity}
                        </span>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          )}

          {/* دسترسی سریع */}
          <div className="flex gap-3">
            <div className="flex-1 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-3 border border-purple-100 dark:border-purple-800">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-bold text-purple-700 dark:text-purple-400">ویژه‌ها</span>
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {menuItems.filter(m => m.isFeatured && m.isAvailable).slice(0, 4).map(item => (
                  <button
                    key={item.id}
                    onClick={() => addToCart(item)}
                    className="px-2.5 py-1 bg-white dark:bg-surface-800 rounded-lg text-xs font-medium text-surface-700 dark:text-surface-300 hover:bg-purple-100 dark:hover:bg-purple-900/30 transition-colors border border-purple-200 dark:border-purple-700"
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex-1 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-xl p-3 border border-blue-100 dark:border-blue-800">
              <div className="flex items-center gap-2 mb-2">
                <Coffee className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-bold text-blue-700 dark:text-blue-400">قهوه‌ها</span>
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {menuItems.filter(m => m.categoryId === categories.find(c => c.slug === 'hot-coffee')?.id && m.isAvailable).slice(0, 4).map(item => (
                  <button
                    key={item.id}
                    onClick={() => addToCart(item)}
                    className="px-2.5 py-1 bg-white dark:bg-surface-800 rounded-lg text-xs font-medium text-surface-700 dark:text-surface-300 hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors border border-blue-200 dark:border-blue-700"
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2 no-scrollbar">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`flex-shrink-0 px-5 py-3 rounded-2xl text-sm font-bold transition-all ${
              selectedCategory === 'all'
                ? 'bg-brand-600 text-white shadow-xl shadow-brand-500/30 scale-105'
                : 'bg-white dark:bg-surface-800 text-surface-600 dark:text-surface-400 hover:bg-surface-50 dark:hover:bg-surface-700 border-2 border-surface-200 dark:border-surface-700'
            }`}
          >
            همه محصولات
          </button>
          {activeCategories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex-shrink-0 px-5 py-3 rounded-2xl text-sm font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-brand-600 text-white shadow-xl shadow-brand-500/30 scale-105'
                  : 'bg-white dark:bg-surface-800 text-surface-600 dark:text-surface-400 hover:bg-surface-50 dark:hover:bg-surface-700 border-2 border-surface-200 dark:border-surface-700'
              }`}
            >
              <span className="ml-2 text-lg">{cat.icon}</span>
              {cat.name}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-surface-400" />
          <input
            type="text"
            placeholder="جستجوی سریع محصول..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pr-12 pl-4 py-4 rounded-2xl bg-white dark:bg-surface-800 border-2 border-surface-200 dark:border-surface-700 text-surface-900 dark:text-surface-100 placeholder:text-surface-400 focus:outline-none focus:ring-4 focus:ring-brand-500/20 focus:border-brand-500 transition-all text-base font-medium"
          />
        </div>

        {/* Items Grid */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredItems.map(item => {
              const inCart = cart.find(c => c.menuItem.id === item.id);
              const isTopSelling = topSellingItems.includes(item.id);
              return (
                <motion.button
                  key={item.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => addToCart(item)}
                  className={`relative p-4 rounded-2xl text-right transition-all ${
                    inCart
                      ? 'bg-brand-50 dark:bg-brand-900/30 border-2 border-brand-500 shadow-lg shadow-brand-500/20'
                      : 'bg-white dark:bg-surface-800 border-2 border-surface-200 dark:border-surface-700 hover:border-brand-400 hover:shadow-lg'
                  }`}
                >
                  {/* Tags */}
                  <div className="absolute top-2 right-2 flex gap-1">
                    {isTopSelling && (
                      <span className="px-2 py-0.5 bg-orange-500 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                        <Flame className="w-3 h-3" /> پرفروش
                      </span>
                    )}
                    {item.isFeatured && !isTopSelling && (
                      <span className="px-2 py-0.5 bg-purple-500 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                        <Star className="w-3 h-3" /> ویژه
                      </span>
                    )}
                  </div>
                  
                  <div className="aspect-square rounded-xl overflow-hidden mb-3 bg-surface-100 dark:bg-surface-700">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <h3 className="font-bold text-surface-900 dark:text-surface-100 text-base truncate">{item.name}</h3>
                  <p className="text-brand-600 dark:text-brand-400 font-black text-lg mt-1">{formatPrice(item.price)}</p>
                  
                  {inCart && (
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -top-2 -left-2 w-10 h-10 bg-brand-600 text-white rounded-full flex items-center justify-center text-base font-black shadow-lg shadow-brand-500/40"
                    >
                      {inCart.quantity}
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Side - Cart */}
      <div className="w-[420px] flex-shrink-0 flex flex-col bg-white dark:bg-surface-900 rounded-3xl border-2 border-surface-200 dark:border-surface-800 overflow-hidden shadow-2xl">
        {/* Cart Header */}
        <div className="p-5 bg-gradient-to-r from-brand-600 to-brand-700 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-black text-xl">سفارش جاری</h3>
                <p className="text-white/70 text-sm">{itemCount} آیتم</p>
              </div>
            </div>
            {cart.length > 0 && (
              <button onClick={() => setCart([])} className="p-2.5 bg-white/20 hover:bg-white/30 rounded-xl transition-colors">
                <Trash2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <AnimatePresence mode="popLayout">
            {cart.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center text-center py-12"
              >
                <div className="w-24 h-24 bg-surface-100 dark:bg-surface-800 rounded-3xl flex items-center justify-center mb-4">
                  <ShoppingCart className="w-12 h-12 text-surface-300 dark:text-surface-600" />
                </div>
                <p className="text-surface-500 font-bold text-lg">سبد خرید خالی است</p>
                <p className="text-surface-400 text-sm mt-1">روی محصولات کلیک کنید</p>
              </motion.div>
            ) : (
              cart.map(c => (
                <motion.div
                  key={c.menuItem.id}
                  layout
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex gap-4 p-4 bg-surface-50 dark:bg-surface-800/50 rounded-2xl"
                >
                  <img src={c.menuItem.image} alt={c.menuItem.name} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-surface-900 dark:text-surface-100 truncate">{c.menuItem.name}</h4>
                    <p className="text-sm text-surface-500 mt-0.5">{formatPrice(c.menuItem.price)}</p>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2 bg-white dark:bg-surface-700 rounded-xl p-1 border border-surface-200 dark:border-surface-600">
                        <button
                          onClick={() => updateQty(c.menuItem.id, c.quantity - 1)}
                          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-colors"
                        >
                          {c.quantity === 1 ? <Trash2 className="w-4 h-4" /> : <Minus className="w-4 h-4" />}
                        </button>
                        <span className="w-8 text-center font-black text-lg text-surface-900 dark:text-surface-100">{c.quantity}</span>
                        <button
                          onClick={() => updateQty(c.menuItem.id, c.quantity + 1)}
                          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-brand-50 hover:text-brand-600 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="font-black text-lg text-surface-900 dark:text-surface-100">
                        {formatPrice(c.menuItem.price * c.quantity)}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>

        {/* Order Type & Payment */}
        {cart.length > 0 && (
          <div className="p-4 border-t-2 border-surface-100 dark:border-surface-800 space-y-4">
            {/* Order Type */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setForm(p => ({ ...p, orderType: 'in-person' }))}
                className={`p-4 rounded-2xl border-2 transition-all flex items-center justify-center gap-3 ${
                  form.orderType === 'in-person'
                    ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400'
                    : 'border-surface-200 dark:border-surface-700 text-surface-500 hover:border-surface-300'
                }`}
              >
                <User className="w-5 h-5" />
                <span className="font-bold">حضوری</span>
              </button>
              <button
                onClick={() => setForm(p => ({ ...p, orderType: 'online' }))}
                className={`p-4 rounded-2xl border-2 transition-all flex items-center justify-center gap-3 ${
                  form.orderType === 'online'
                    ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400'
                    : 'border-surface-200 dark:border-surface-700 text-surface-500 hover:border-surface-300'
                }`}
              >
                <Smartphone className="w-5 h-5" />
                <span className="font-bold">آنلاین</span>
              </button>
            </div>

            {/* Payment Method */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'cash', label: 'نقدی', icon: Banknote },
                { value: 'card', label: 'کارت', icon: CreditCard },
                { value: 'other', label: 'سایر', icon: Smartphone },
              ].map(pm => (
                <button
                  key={pm.value}
                  onClick={() => setForm(p => ({ ...p, paymentMethod: pm.value as PaymentMethod }))}
                  className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1.5 ${
                    form.paymentMethod === pm.value
                      ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400'
                      : 'border-surface-200 dark:border-surface-700 text-surface-500 hover:border-surface-300'
                  }`}
                >
                  <pm.icon className="w-5 h-5" />
                  <span className="text-sm font-bold">{pm.label}</span>
                </button>
              ))}
            </div>

            {/* Customer & Discount */}
            <div className="flex gap-3">
              <button
                onClick={() => setCustomerModal(true)}
                className="flex-1 p-4 rounded-2xl border-2 border-surface-200 dark:border-surface-700 text-surface-600 dark:text-surface-400 hover:border-brand-400 hover:text-brand-600 transition-colors flex items-center justify-center gap-2"
              >
                <User className="w-5 h-5" />
                <span className="font-bold">{form.firstName ? `${form.firstName} ${form.lastName}` : 'اطلاعات مشتری'}</span>
              </button>
              <div className="w-32">
                <input
                  type="number"
                  placeholder="تخفیف"
                  value={form.discount || ''}
                  onChange={e => setForm(p => ({ ...p, discount: parseInt(e.target.value) || 0 }))}
                  className="w-full p-4 rounded-2xl border-2 border-surface-200 dark:border-surface-700 bg-transparent text-center font-bold text-surface-900 dark:text-surface-100 placeholder:text-surface-400 focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* Total & Submit */}
        {cart.length > 0 && (
          <div className="p-5 bg-surface-50 dark:bg-surface-800/50 border-t-2 border-surface-100 dark:border-surface-800">
            <div className="space-y-2 mb-5">
              <div className="flex justify-between text-base">
                <span className="text-surface-500">جمع کل</span>
                <span className="font-bold text-surface-900 dark:text-surface-100">{formatPrice(subtotal)}</span>
              </div>
              {form.discount > 0 && (
                <div className="flex justify-between text-base">
                  <span className="text-surface-500">تخفیف</span>
                  <span className="font-bold text-emerald-600">-{formatPrice(form.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-2xl font-black pt-3 border-t-2 border-dashed border-surface-200 dark:border-surface-700">
                <span className="text-surface-900 dark:text-surface-100">مبلغ نهایی</span>
                <span className="text-brand-600">{formatPrice(total)}</span>
              </div>
            </div>
            <Button 
              className="w-full !py-5 !text-lg !font-black !rounded-2xl !bg-brand-600 hover:!bg-brand-700 !shadow-xl !shadow-brand-500/30" 
              size="lg" 
              onClick={handleSubmit}
            >
              <Zap className="w-6 h-6 ml-2" />
              ثبت سفارش
            </Button>
          </div>
        )}
      </div>

      {/* Customer Modal */}
      <Modal open={customerModal} onClose={() => setCustomerModal(false)} title="اطلاعات مشتری">
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="نام" placeholder="نام" value={form.firstName} onChange={e => setForm(p => ({ ...p, firstName: e.target.value }))} />
            <Input label="نام خانوادگی" placeholder="نام خانوادگی" value={form.lastName} onChange={e => setForm(p => ({ ...p, lastName: e.target.value }))} />
          </div>
          <Input label="شماره تماس" placeholder="۰۹۱۲۳۴۵۶۷۸۹" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
          <Textarea label="یادداشت" placeholder="توضیحات سفارش..." value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} />
          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={() => setCustomerModal(false)}>انصراف</Button>
            <Button onClick={() => setCustomerModal(false)}>تأیید</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
