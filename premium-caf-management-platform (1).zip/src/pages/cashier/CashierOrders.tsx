import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChefHat, CheckCircle2, Clock, Bell, User, ChevronLeft } from 'lucide-react';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/fa';
import { cn } from '@/utils/cn';
import { useAppStore, formatPrice } from '@/store';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import type { Order, OrderStatus } from '@/types';

dayjs.extend(relativeTime);
dayjs.locale('fa');

const statusConfig = {
  pending: { label: 'در انتظار', color: 'bg-amber-500', bgColor: 'bg-amber-50 dark:bg-amber-900/20', textColor: 'text-amber-700 dark:text-amber-400', next: 'preparing' as OrderStatus, nextLabel: 'شروع پخت' },
  preparing: { label: 'در حال آماده‌سازی', color: 'bg-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-900/20', textColor: 'text-blue-700 dark:text-blue-400', next: 'ready' as OrderStatus, nextLabel: 'آماده شد' },
  ready: { label: 'آماده تحویل', color: 'bg-emerald-500', bgColor: 'bg-emerald-50 dark:bg-emerald-900/20', textColor: 'text-emerald-700 dark:text-emerald-400', next: 'delivered' as OrderStatus, nextLabel: 'تحویل داده شد' },
};

export default function CashierOrders() {
  const { orders, updateOrderStatus } = useAppStore();
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus | 'all'>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const activeOrders = orders.filter(o => ['pending', 'preparing', 'ready'].includes(o.status));
  const filteredOrders = selectedStatus === 'all' 
    ? activeOrders 
    : orders.filter(o => o.status === selectedStatus);

  const statusCounts: Record<string, number> = {
    pending: orders.filter(o => o.status === 'pending').length,
    preparing: orders.filter(o => o.status === 'preparing').length,
    ready: orders.filter(o => o.status === 'ready').length,
  };

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    updateOrderStatus(orderId, newStatus);
    if (selectedOrder?.id === orderId) {
      setSelectedOrder({ ...selectedOrder, status: newStatus });
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-black text-surface-900 dark:text-surface-100">سفارش‌های فعال</h1>
        <p className="text-surface-500 dark:text-surface-400 mt-1">
          {activeOrders.length} سفارش در انتظار پردازش
        </p>
      </div>

      {/* Status Cards - BIG & BOLD */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {Object.entries(statusConfig).map(([status, config]) => {
          const count = statusCounts[status as OrderStatus] || 0;
          const isActive = selectedStatus === status;
          
          return (
            <motion.button
              key={status}
              whileTap={{ scale: 0.97 }}
              onClick={() => setSelectedStatus(selectedStatus === status ? 'all' : status as OrderStatus)}
              className={cn(
                'p-6 rounded-3xl border-3 transition-all text-right',
                isActive
                  ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/30 shadow-xl shadow-brand-500/20 scale-[1.02]'
                  : 'border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 hover:border-surface-300 hover:shadow-lg'
              )}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={cn('w-14 h-14 rounded-2xl flex items-center justify-center', config.bgColor)}>
                  {status === 'pending' && <Clock className={cn('w-7 h-7', config.textColor)} />}
                  {status === 'preparing' && <ChefHat className={cn('w-7 h-7', config.textColor)} />}
                  {status === 'ready' && <CheckCircle2 className={cn('w-7 h-7', config.textColor)} />}
                </div>
                {count > 0 && (
                  <span className="text-4xl font-black text-surface-900 dark:text-surface-100">{count}</span>
                )}
              </div>
              <p className="font-bold text-lg text-surface-900 dark:text-surface-100">{config.label}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className={cn('w-2.5 h-2.5 rounded-full', config.color, count > 0 && 'animate-pulse')} />
                <span className="text-sm text-surface-500">{count > 0 ? 'نیاز به اقدام' : 'خالی'}</span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <AnimatePresence mode="popLayout">
          {filteredOrders.map((order, index) => {
            const config = statusConfig[order.status as keyof typeof statusConfig];
            if (!config) return null;
            
            const timeAgo = dayjs(order.createdAt).fromNow();
            const isUrgent = dayjs().diff(dayjs(order.createdAt), 'minute') > 15 && order.status === 'pending';

            return (
              <motion.div
                key={order.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setSelectedOrder(order)}
                className={cn(
                  'bg-white dark:bg-surface-800 rounded-3xl border-2 p-5 cursor-pointer transition-all hover:shadow-xl',
                  isUrgent 
                    ? 'border-red-300 dark:border-red-800 shadow-red-100 dark:shadow-red-900/20' 
                    : 'border-surface-200 dark:border-surface-700 hover:border-brand-300'
                )}
              >
                {/* Order Header */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-lg font-black text-surface-900 dark:text-surface-100" dir="ltr">
                        #{order.orderNumber.replace('COOL-', '')}
                      </span>
                      {isUrgent && (
                        <span className="px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded-full animate-pulse flex items-center gap-1">
                          <Bell className="w-3 h-3" />
                          فوری
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-surface-400 mt-1">{timeAgo}</p>
                  </div>
                  <div className={cn('px-3 py-1.5 rounded-xl', config.bgColor)}>
                    <span className={cn('text-sm font-bold', config.textColor)}>{config.label}</span>
                  </div>
                </div>

                {/* Customer */}
                <div className="flex items-center gap-3 mb-4 p-3 bg-surface-50 dark:bg-surface-900 rounded-xl">
                  <div className="w-10 h-10 bg-brand-100 dark:bg-brand-900/30 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-brand-600 dark:text-brand-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-surface-900 dark:text-surface-100">
                      {order.customerFirstName} {order.customerLastName}
                    </p>
                    {order.customerPhone && (
                      <p className="text-xs text-surface-400 font-mono" dir="ltr">{order.customerPhone}</p>
                    )}
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-surface-400">نوع</p>
                    <Badge variant={order.orderType === 'online' ? 'info' : 'default'}>
                      {order.orderType === 'online' ? 'آنلاین' : 'حضوری'}
                    </Badge>
                  </div>
                </div>

                {/* Items - Compact */}
                <div className="space-y-2 mb-4">
                  {order.items.slice(0, 3).map(item => (
                    <div key={item.id} className="flex items-center justify-between text-sm">
                      <span className="text-surface-600 dark:text-surface-400">
                        <span className="font-bold text-surface-900 dark:text-surface-100">{item.quantity}×</span> {item.name}
                      </span>
                      <span className="font-medium text-surface-700 dark:text-surface-300">{formatPrice(item.subtotal)}</span>
                    </div>
                  ))}
                  {order.items.length > 3 && (
                    <p className="text-xs text-surface-400">+ {order.items.length - 3} آیتم دیگر</p>
                  )}
                </div>

                {/* Note */}
                {order.notes && (
                  <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-200 dark:border-amber-800">
                    <p className="text-sm text-amber-700 dark:text-amber-400">{order.notes}</p>
                  </div>
                )}

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t-2 border-dashed border-surface-200 dark:border-surface-700">
                  <span className="text-2xl font-black text-brand-600">{formatPrice(order.total)}</span>
                  {config.next && (
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStatusChange(order.id, config.next);
                      }}
                      className="!py-3 !px-6 !rounded-xl !font-bold"
                    >
                      {config.nextLabel}
                      <ChevronLeft className="w-4 h-4 mr-1" />
                    </Button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {filteredOrders.length === 0 && (
        <div className="text-center py-20">
          <div className="w-20 h-20 bg-surface-100 dark:bg-surface-800 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-surface-300 dark:text-surface-600" />
          </div>
          <p className="text-xl font-bold text-surface-500 dark:text-surface-400">سفارشی وجود ندارد</p>
          <p className="text-surface-400 text-sm mt-1">همه سفارش‌ها پردازش شده‌اند</p>
        </div>
      )}

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSelectedOrder(null)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-white dark:bg-surface-900 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white dark:bg-surface-900 border-b border-surface-100 dark:border-surface-800 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-surface-900 dark:text-surface-100">
                سفارش <span dir="ltr">{selectedOrder.orderNumber}</span>
              </h2>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-2 hover:bg-surface-100 dark:hover:bg-surface-800 rounded-xl transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-surface-400" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Status */}
              <div className={cn(
                'p-4 rounded-2xl',
                statusConfig[selectedOrder.status as keyof typeof statusConfig]?.bgColor
              )}>
                <p className="text-sm text-surface-500">وضعیت</p>
                <p className={cn(
                  'text-xl font-bold mt-1',
                  statusConfig[selectedOrder.status as keyof typeof statusConfig]?.textColor
                )}>
                  {statusConfig[selectedOrder.status as keyof typeof statusConfig]?.label}
                </p>
              </div>

              {/* Customer */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 bg-surface-50 dark:bg-surface-800 rounded-2xl">
                  <p className="text-xs text-surface-400 mb-1">مشتری</p>
                  <p className="font-bold text-surface-900 dark:text-surface-100">
                    {selectedOrder.customerFirstName} {selectedOrder.customerLastName}
                  </p>
                </div>
                <div className="p-4 bg-surface-50 dark:bg-surface-800 rounded-2xl">
                  <p className="text-xs text-surface-400 mb-1">تلفن</p>
                  <p className="font-bold text-surface-900 dark:text-surface-100" dir="ltr">
                    {selectedOrder.customerPhone || '—'}
                  </p>
                </div>
              </div>

              {/* Items */}
              <div>
                <p className="text-sm font-bold text-surface-500 mb-3">آیتم‌ها</p>
                <div className="space-y-2">
                  {selectedOrder.items.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-surface-50 dark:bg-surface-800 rounded-xl">
                      <div>
                        <p className="font-bold text-surface-900 dark:text-surface-100">{item.name}</p>
                        <p className="text-sm text-surface-500">{item.quantity} × {formatPrice(item.price)}</p>
                      </div>
                      <p className="font-black text-lg text-surface-900 dark:text-surface-100">{formatPrice(item.subtotal)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="pt-4 border-t-2 border-dashed border-surface-200 dark:border-surface-700">
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-surface-900 dark:text-surface-100">مبلغ نهایی</span>
                  <span className="text-3xl font-black text-brand-600">{formatPrice(selectedOrder.total)}</span>
                </div>
              </div>

              {/* Notes */}
              {selectedOrder.notes && (
                <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-2xl border-2 border-amber-200 dark:border-amber-800">
                  <p className="text-sm font-bold text-amber-700 dark:text-amber-400 mb-1">یادداشت</p>
                  <p className="text-amber-800 dark:text-amber-300">{selectedOrder.notes}</p>
                </div>
              )}

              {/* Actions */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                {statusConfig[selectedOrder.status as keyof typeof statusConfig]?.next && (
                  <Button
                    className="col-span-2 !py-4 !text-lg !font-black !rounded-2xl"
                    onClick={() => {
                      const next = statusConfig[selectedOrder.status as keyof typeof statusConfig].next;
                      handleStatusChange(selectedOrder.id, next);
                      setSelectedOrder(null);
                    }}
                  >
                    {statusConfig[selectedOrder.status as keyof typeof statusConfig].nextLabel}
                  </Button>
                )}
                <Button variant="outline" className="col-span-2" onClick={() => setSelectedOrder(null)}>
                  بستن
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
